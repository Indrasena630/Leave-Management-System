package com.company.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.company.lms.dto.EmployeeCreateRequest;
import com.company.lms.dto.LeaveBalanceResponse;
import com.company.lms.entity.Employee;
import com.company.lms.service.EmployeeService;
import com.company.lms.service.LeaveService;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private LeaveService leaveService;

    // ✅ Add Employee
    @PostMapping
    public ResponseEntity<Employee> addEmployee(@Validated @RequestBody EmployeeCreateRequest req) {
        Employee employee = employeeService.addEmployee(req);
        return ResponseEntity.ok(employee);
    }

    // ✅ Get Balance of Employee
    @GetMapping("/{id}/balance")
    public ResponseEntity<LeaveBalanceResponse> getBalance(@PathVariable Long id) {
        LeaveBalanceResponse balance = leaveService.getBalance(id);
        return ResponseEntity.ok(balance);
    }

    // ✅ Get Employee by ID (missing method added)
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployee(@PathVariable Long id) {
        Employee employee = employeeService.getEmployee(id);
        return ResponseEntity.ok(employee);
    }
}
