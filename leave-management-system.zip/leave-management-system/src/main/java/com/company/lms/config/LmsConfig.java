package com.company.lms.config;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LmsConfig {
    @Value("${lms.annual.allocation:24}")
    public int annualAllocation;

    @Value("${lms.exclude.weekends:true}")
    public boolean excludeWeekends;
}
