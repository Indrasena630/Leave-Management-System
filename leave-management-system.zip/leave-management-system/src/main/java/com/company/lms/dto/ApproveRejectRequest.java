package com.company.lms.dto;



import jakarta.validation.constraints.*;

public record ApproveRejectRequest(
        @NotNull Long approverId,
        String comment
) {}
