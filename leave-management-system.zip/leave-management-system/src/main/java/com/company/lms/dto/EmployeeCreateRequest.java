package com.company.lms.dto;



import jakarta.validation.constraints.*;
import java.time.LocalDate;

public record EmployeeCreateRequest(
        @NotBlank String name,
        @Email @NotBlank String email,
        @NotBlank String department,
        @NotNull LocalDate joiningDate,
        Integer initialAllocation // optional override
) {}
