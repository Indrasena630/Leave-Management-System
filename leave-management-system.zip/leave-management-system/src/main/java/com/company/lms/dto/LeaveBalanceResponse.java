package com.company.lms.dto;



public record LeaveBalanceResponse(
        Long employeeId,
        String employeeName,
        int allocated,
        int used,
        int remaining
) {}
