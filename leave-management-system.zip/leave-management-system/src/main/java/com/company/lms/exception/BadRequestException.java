package com.company.lms.exception;



public class BadRequestException extends RuntimeException {
    public BadRequestException(String m) { super(m); }
}
