package com.company.lms.service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.company.lms.config.LmsConfig;
import com.company.lms.dto.LeaveApplyRequest;
import com.company.lms.dto.LeaveBalanceResponse;
import com.company.lms.entity.Employee;
import com.company.lms.entity.LeaveBalance;
import com.company.lms.entity.LeaveRequest;
import com.company.lms.entity.LeaveStatus;
import com.company.lms.exception.BadRequestException;
import com.company.lms.exception.NotFoundException;
import com.company.lms.repository.EmployeeRepository;
import com.company.lms.repository.LeaveBalanceRepository;
import com.company.lms.repository.LeaveRequestRepository;

@Service
public class LeaveService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private LeaveRequestRepository leaveRepository;

    @Autowired
    private LeaveBalanceRepository balanceRepository;

    @Autowired
    private LmsConfig config;

    @Transactional
    public LeaveRequest apply(LeaveApplyRequest req) {
        Employee emp = employeeRepository.findById(req.employeeId())
                .orElseThrow(() -> new NotFoundException("Employee not found"));

        LocalDate start = req.startDate();
        LocalDate end = req.endDate();

        if (end.isBefore(start)) {
            throw new BadRequestException("End date cannot be before start date");
        }
        if (start.isBefore(emp.getJoiningDate())) {
            throw new BadRequestException("Cannot apply leave before joining date");
        }

        int days = computeDays(start, end);

        LeaveBalance bal = balanceRepository.findByEmployeeId(emp.getId())
                .orElseThrow(() -> new NotFoundException("Leave balance not found"));
        if (days <= 0) {
            throw new BadRequestException("Leave days must be positive");
        }
        if (days > bal.getRemaining()) {
            throw new BadRequestException("Insufficient leave balance. Remaining: " + bal.getRemaining());
        }

        // Overlap check (replacing lambda with loop)
        List<LeaveRequest> overlaps = leaveRepository
                .findByEmployeeAndStartDateLessThanEqualAndEndDateGreaterThanEqual(emp, end, start);

        boolean overlapping = false;
        for (LeaveRequest lr : overlaps) {
            if (lr.getStatus() != LeaveStatus.REJECTED) {
                overlapping = true;
                break;
            }
        }
        if (overlapping) {
            throw new BadRequestException("Overlapping with existing leave (pending/approved)");
        }

        LeaveRequest lr = LeaveRequest.builder()
                .employee(emp)
                .startDate(start)
                .endDate(end)
                .days(days)
                .status(LeaveStatus.PENDING)
                .reason(req.reason())
                .build();

        return leaveRepository.save(lr);
    }

    @Transactional
    public LeaveRequest approve(Long leaveId, Long approverId, String comment) {
        LeaveRequest lr = leaveRepository.findById(leaveId)
                .orElseThrow(() -> new NotFoundException("Leave not found"));

        if (lr.getStatus() != LeaveStatus.PENDING) {
            throw new BadRequestException("Only PENDING leaves can be approved");
        }

        LeaveBalance bal = balanceRepository.findByEmployeeId(lr.getEmployee().getId())
                .orElseThrow(() -> new NotFoundException("Leave balance not found"));

        if (lr.getDays() > bal.getRemaining()) {
            throw new BadRequestException("Insufficient balance at approval time");
        }

        bal.setUsedDays(bal.getUsedDays() + lr.getDays());
        lr.setStatus(LeaveStatus.APPROVED);
        lr.setManagerComment(comment);

        balanceRepository.save(bal);
        return leaveRepository.save(lr);
    }

    @Transactional
    public LeaveRequest reject(Long leaveId, Long approverId, String comment) {
        LeaveRequest lr = leaveRepository.findById(leaveId)
                .orElseThrow(() -> new NotFoundException("Leave not found"));

        if (lr.getStatus() != LeaveStatus.PENDING) {
            throw new BadRequestException("Only PENDING leaves can be rejected");
        }

        lr.setStatus(LeaveStatus.REJECTED);
        lr.setManagerComment(comment);

        return leaveRepository.save(lr);
    }

    public LeaveBalanceResponse getBalance(Long employeeId) {
        Employee emp = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new NotFoundException("Employee not found"));

        LeaveBalance bal = balanceRepository.findByEmployeeId(employeeId)
                .orElseThrow(() -> new NotFoundException("Balance not found"));

        return new LeaveBalanceResponse(
                emp.getId(),
                emp.getName(),
                bal.getAllocatedDays(),
                bal.getUsedDays(),
                bal.getRemaining()
        );
    }

    private int computeDays(LocalDate start, LocalDate end) {
        int days = 0;
        LocalDate d = start;
        while (!d.isAfter(end)) {
            if (!config.excludeWeekends
                    || (d.getDayOfWeek() != DayOfWeek.SATURDAY && d.getDayOfWeek() != DayOfWeek.SUNDAY)) {
                days++;
            }
            d = d.plusDays(1);
        }
        return days;
    }
}
