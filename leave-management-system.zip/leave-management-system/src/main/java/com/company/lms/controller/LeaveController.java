package com.company.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.company.lms.dto.ApproveRejectRequest;
import com.company.lms.dto.LeaveApplyRequest;
import com.company.lms.entity.LeaveRequest;
import com.company.lms.service.LeaveService;

@RestController
@RequestMapping("/api/leaves")
public class LeaveController {

    @Autowired
    private LeaveService leaveService;

    @PostMapping("/apply")
    public ResponseEntity<LeaveRequest> apply(@Validated @RequestBody LeaveApplyRequest req) {
        LeaveRequest leaveRequest = leaveService.apply(req);
        return ResponseEntity.ok(leaveRequest);
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<LeaveRequest> approve(@PathVariable Long id, @Validated @RequestBody ApproveRejectRequest req) {
        LeaveRequest leaveRequest = leaveService.approve(id, req.approverId(), req.comment());
        return ResponseEntity.ok(leaveRequest);
    }

    @PostMapping("/{id}/reject")
    public ResponseEntity<LeaveRequest> reject(@PathVariable Long id, @Validated @RequestBody ApproveRejectRequest req) {
        LeaveRequest leaveRequest = leaveService.reject(id, req.approverId(), req.comment());
        return ResponseEntity.ok(leaveRequest);
    }
}
