package com.company.lms.entity;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
