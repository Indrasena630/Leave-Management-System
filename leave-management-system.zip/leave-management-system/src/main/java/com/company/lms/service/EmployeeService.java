package com.company.lms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.company.lms.config.LmsConfig;
import com.company.lms.dto.EmployeeCreateRequest;
import com.company.lms.entity.Employee;
import com.company.lms.entity.LeaveBalance;
import com.company.lms.exception.BadRequestException;
import com.company.lms.exception.NotFoundException;
import com.company.lms.repository.EmployeeRepository;
import com.company.lms.repository.LeaveBalanceRepository;

import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private LeaveBalanceRepository balanceRepository;

    @Autowired
    private LmsConfig config;

    @Transactional
    public Employee addEmployee(EmployeeCreateRequest req) {
        // Check if email already exists
        Optional<Employee> existing = employeeRepository.findByEmail(req.email());
        if (existing.isPresent()) {
            throw new BadRequestException("Email already exists");
        }

        int allocation;
        if (req.initialAllocation() != null) {
            allocation = req.initialAllocation();
        } else {
            allocation = config.annualAllocation;
        }

        Employee e = Employee.builder()
                .name(req.name())
                .email(req.email())
                .department(req.department())
                .joiningDate(req.joiningDate())
                .build();

        e = employeeRepository.save(e);

        LeaveBalance lb = LeaveBalance.builder()
                .employee(e)
                .allocatedDays(allocation)
                .usedDays(0)
                .build();

        balanceRepository.save(lb);
        e.setBalance(lb);

        return e;
    }

    public LeaveBalance getBalance(Long employeeId) {
        Optional<LeaveBalance> balanceOpt = balanceRepository.findByEmployeeId(employeeId);
        if (balanceOpt.isEmpty()) {
            throw new NotFoundException("Employee or balance not found");
        }
        return balanceOpt.get();
    }

    public Employee getEmployee(Long id) {
        Optional<Employee> empOpt = employeeRepository.findById(id);
        if (empOpt.isEmpty()) {
            throw new NotFoundException("Employee not found");
        }
        return empOpt.get();
    }
}
