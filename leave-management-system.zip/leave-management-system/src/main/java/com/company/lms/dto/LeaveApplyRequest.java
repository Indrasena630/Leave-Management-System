package com.company.lms.dto;



import jakarta.validation.constraints.*;
import java.time.LocalDate;

public record LeaveApplyRequest(
        @NotNull Long employeeId,
        @NotNull LocalDate startDate,
        @NotNull LocalDate endDate,
        String reason
) {}
