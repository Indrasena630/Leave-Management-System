package com.company.lms.repository;



import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.company.lms.entity.Employee;
import com.company.lms.entity.LeaveRequest;
import com.company.lms.entity.LeaveStatus;


public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {
    List<LeaveRequest> findByEmployee(Employee employee);
    List<LeaveRequest> findByEmployeeAndStatusIn(Employee employee, List<LeaveStatus> statuses);
    List<LeaveRequest> findByEmployeeAndStatus(Employee employee, LeaveStatus status);
    List<LeaveRequest> findByEmployeeAndStartDateLessThanEqualAndEndDateGreaterThanEqual(Employee employee, LocalDate end, LocalDate start);
}
