package com.company.lms.repository;



import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.company.lms.entity.LeaveBalance;


public interface LeaveBalanceRepository extends JpaRepository<LeaveBalance, Long> {
    Optional<LeaveBalance> findByEmployeeId(Long employeeId);
}
